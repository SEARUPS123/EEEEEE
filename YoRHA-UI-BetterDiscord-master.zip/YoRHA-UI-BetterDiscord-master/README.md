# YoRHa-UI-BetterDiscord
Better Discord theme based around NieR: Automata's Menu UI

Available in light and dark mode!

Theme also works in both compact and cozy mode! c:

If you have any issues, best way to contact me is to join the support server and send screencaps there etc. https://discord.gg/X4nBPCa

THANKS TO JulioDRai FOR LETTING ME USE THEIR CURSORS (and for forgiving me for using them for so long without asking first for permission <3 ;-;) (https://www.deviantart.com/juliodrai)

THANKS TO GOmonkeymanGO FOR LETTING ME USE SOME OF HIS CODE ON HIS NIER UI THEME, https://github.com/ChaseIngebritson/YoRHa-Discord-Theme

![Image of Theme Preview](https://raw.githubusercontent.com/AccraZed/YoRHA-UI-BetterDiscord/master/Previews/preview3.png)
![Image of Theme Preview](https://raw.githubusercontent.com/AccraZed/YoRHA-UI-BetterDiscord/master/Previews/preview1.png)
![Image of Theme Preview](https://raw.githubusercontent.com/AccraZed/YoRHA-UI-BetterDiscord/master/Previews/preview2.png)

Dark Mode
![Image of Theme Preview](https://raw.githubusercontent.com/AccraZed/YoRHA-UI-BetterDiscord/master/Previews/dark-1.png)
